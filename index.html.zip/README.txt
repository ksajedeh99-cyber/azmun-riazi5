راهنمای GitHub Pages:
1. در GitHub یک Repository جدید بسازید.
2. فایل index.html را Upload کنید و Commit بزنید.
3. Settings > Pages را باز کنید.
4. در Source گزینه Deploy from a branch، شاخه main و پوشه / (root) را انتخاب کنید.
5. Save را بزنید. بعد از انتشار، لینک نمایش‌داده‌شده را برای دانش‌آموزان بفرستید.
